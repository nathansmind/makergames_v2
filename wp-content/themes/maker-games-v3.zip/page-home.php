<?php
/*
  Template Name: Home
 */
?>

<?php get_header(); ?>
<div id="content" class="home">

</div><!--#content .home-->
<?php get_footer(); ?>